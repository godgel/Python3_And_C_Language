# This Program was made to check type of value.

import sys

def chech_type_size(left_var, right_var):
    temp_param_type = type(left_var)
    temp_param_size = sys.getsizeof(right_var)
    return temp_param_type, temp_param_size

print(" \n --- Please Input left, And Righr Number --- \n ")

temp_left_var = ''
temp_right_var = ''

temp_left = input(temp_left_var)

temp_right = input(temp_right_var)

temp_left, temp_right = chech_type_size(temp_left, temp_right)


print(f" \n Type Of Left_Var is {}, Right_Var is {}", temp_param_type, temp_param_size )





